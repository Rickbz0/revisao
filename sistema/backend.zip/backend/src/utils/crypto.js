// Algoritimo: AES-256-CBC
// Chave: 32 bytes (256 bits)
// IV: 16 bytes (128 bits)

import crypto from 'crypto';

const algorithm = 'aes-256-cbc';
const secretKey = Buffer.from(process.env.CRYPTO_SECRET || '12345678901234567890123456789012');
const inicialIV = Buffer.from(process.env.CRYPTO_IV || '1234567890123456');

export function encrypt(text) {
    if (!text) return text;
    try {
        const cipher = crypto.createCipher(algorithm, secretKey);
        let encrypted = cipher.update(text, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        return encrypted;
    } catch (error) {
        console.error('Erro ao criptografar texto:', error.message);
        return text
    }
}

export default {
    encrypt
};
