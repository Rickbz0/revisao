
import { Router } from 'express';
import ClienteController from '../controllers/ClienteController.js';

const router = Router();

const clienteController = new ClienteController();

// Rotas para clientes
router.get('/clientes', clienteController.listar);
router.post('/clientes', clienteController.criar);

export default router;
